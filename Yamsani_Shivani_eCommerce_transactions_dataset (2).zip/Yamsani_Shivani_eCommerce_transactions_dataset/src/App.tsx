import React, { useEffect, useState } from 'react';
import { BarChart, LineChart, PieChart, Activity, Users, TrendingUp } from 'lucide-react';
import {
  ResponsiveContainer,
  BarChart as RechartsBarChart,
  Bar,
  LineChart as RechartsLineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid
} from 'recharts';

const sampleData = {
  total_revenue: 1234567.89,
  avg_order_value: 285.45,
  category_metrics: {
    revenue: {
      'Electronics': 425000,
      'Clothing': 350000,
      'Books': 275000,
      'Home Decor': 184567.89
    },
    orders: {
      'Electronics': 1250,
      'Clothing': 1100,
      'Books': 950,
      'Home Decor': 700
    }
  },
  regional_metrics: {
    revenue: {
      'North America': 450000,
      'Europe': 350000,
      'Asia': 275000,
      'South America': 159567.89
    },
    customers: {
      'North America': 65,
      'Europe': 55,
      'Asia': 45,
      'South America': 35
    },
    avg_revenue_per_customer: {
      'North America': 6923.08,
      'Europe': 6363.64,
      'Asia': 6111.11,
      'South America': 4559.08
    }
  },
  time_series: {
    dates: ['2024-01-01', '2024-01-02', '2024-01-03', '2024-01-04', '2024-01-05', '2024-01-06', '2024-01-07'],
    revenue: [15000, 17500, 14000, 16000, 18500, 19000, 17000],
    moving_avg: [null, null, 15500, 15833.33, 16250, 17000, 17333.33]
  }
};

function App() {
  const [activeTab, setActiveTab] = useState<'eda' | 'lookalike' | 'clustering'>('eda');

  return (
    <div className="min-h-screen bg-gray-50">
      <nav className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex">
              <div className="flex-shrink-0 flex items-center">
                <Activity className="h-8 w-8 text-indigo-600" />
                <span className="ml-2 text-xl font-bold text-gray-900">eCommerce Analytics</span>
              </div>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex space-x-4 mb-8">
          <button
            onClick={() => setActiveTab('eda')}
            className={`px-4 py-2 rounded-md flex items-center ${
              activeTab === 'eda' ? 'bg-indigo-600 text-white' : 'bg-white text-gray-700'
            }`}
          >
            <BarChart className="mr-2 h-5 w-5" />
            EDA & Insights
          </button>
          <button
            onClick={() => setActiveTab('lookalike')}
            className={`px-4 py-2 rounded-md flex items-center ${
              activeTab === 'lookalike' ? 'bg-indigo-600 text-white' : 'bg-white text-gray-700'
            }`}
          >
            <Users className="mr-2 h-5 w-5" />
            Lookalike Analysis
          </button>
          <button
            onClick={() => setActiveTab('clustering')}
            className={`px-4 py-2 rounded-md flex items-center ${
              activeTab === 'clustering' ? 'bg-indigo-600 text-white' : 'bg-white text-gray-700'
            }`}
          >
            <TrendingUp className="mr-2 h-5 w-5" />
            Customer Segmentation
          </button>
        </div>

        {activeTab === 'eda' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white p-6 rounded-lg shadow">
                <h2 className="text-xl font-semibold mb-4">Revenue Trends</h2>
                <ResponsiveContainer width="100%" height={300}>
                  <RechartsLineChart data={sampleData.time_series.dates.map((date, i) => ({
                    date,
                    revenue: sampleData.time_series.revenue[i],
                    moving_avg: sampleData.time_series.moving_avg[i]
                  }))}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="revenue" stroke="#4f46e5" name="Daily Revenue" />
                    <Line type="monotone" dataKey="moving_avg" stroke="#ef4444" name="7-Day Moving Average" />
                  </RechartsLineChart>
                </ResponsiveContainer>
              </div>

              <div className="bg-white p-6 rounded-lg shadow">
                <h2 className="text-xl font-semibold mb-4">Category Performance</h2>
                <ResponsiveContainer width="100%" height={300}>
                  <RechartsBarChart data={Object.entries(sampleData.category_metrics.revenue).map(([name, value]) => ({
                    name,
                    revenue: value,
                    orders: sampleData.category_metrics.orders[name]
                  }))}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis yAxisId="left" />
                    <YAxis yAxisId="right" orientation="right" />
                    <Tooltip />
                    <Legend />
                    <Bar yAxisId="left" dataKey="revenue" fill="#4f46e5" name="Revenue" />
                    <Bar yAxisId="right" dataKey="orders" fill="#ef4444" name="Orders" />
                  </RechartsBarChart>
                </ResponsiveContainer>
              </div>
            </div>

            <div className="bg-white p-6 rounded-lg shadow">
              <h2 className="text-xl font-semibold mb-4">Regional Analysis</h2>
              <ResponsiveContainer width="100%" height={300}>
                <RechartsBarChart data={Object.entries(sampleData.regional_metrics.revenue).map(([name, value]) => ({
                  name,
                  revenue: value,
                  customers: sampleData.regional_metrics.customers[name],
                  avg_revenue: sampleData.regional_metrics.avg_revenue_per_customer[name]
                }))}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="revenue" fill="#4f46e5" name="Total Revenue" />
                  <Bar dataKey="customers" fill="#ef4444" name="Number of Customers" />
                  <Bar dataKey="avg_revenue" fill="#22c55e" name="Avg Revenue per Customer" />
                </RechartsBarChart>
              </ResponsiveContainer>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="bg-white p-6 rounded-lg shadow">
                <h3 className="text-lg font-semibold mb-2">Total Revenue</h3>
                <p className="text-3xl font-bold text-indigo-600">
                  ${sampleData.total_revenue.toLocaleString()}
                </p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow">
                <h3 className="text-lg font-semibold mb-2">Average Order Value</h3>
                <p className="text-3xl font-bold text-indigo-600">
                  ${sampleData.avg_order_value.toLocaleString()}
                </p>
              </div>
              <div className="bg-white p-6 rounded-lg shadow">
                <h3 className="text-lg font-semibold mb-2">Total Orders</h3>
                <p className="text-3xl font-bold text-indigo-600">
                  {Object.values(sampleData.category_metrics.orders).reduce((a, b) => a + b, 0).toLocaleString()}
                </p>
              </div>
            </div>
          </div>
        )}

        {activeTab === 'lookalike' && (
          <div className="bg-white p-6 rounded-lg shadow">
            <h2 className="text-xl font-semibold mb-4">Customer Lookalike Analysis</h2>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead>
                  <tr>
                    <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Customer ID
                    </th>
                    <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Similar Customers
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      C0001
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      C0034 (Score: 0.92), C0156 (Score: 0.89), C0078 (Score: 0.85)
                    </td>
                  </tr>
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      C0002
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      C0089 (Score: 0.88), C0145 (Score: 0.86), C0023 (Score: 0.83)
                    </td>
                  </tr>
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      C0003
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      C0167 (Score: 0.91), C0045 (Score: 0.87), C0198 (Score: 0.84)
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        )}

        {activeTab === 'clustering' && (
          <div className="space-y-6">
            <div className="bg-white p-6 rounded-lg shadow">
              <h2 className="text-xl font-semibold mb-4">Customer Segments</h2>
              <div className="mb-4">
                <p className="text-gray-700">
                  Optimal number of clusters: <span className="font-bold">4</span>
                </p>
              </div>
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead>
                    <tr>
                      <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Cluster
                      </th>
                      <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Size
                      </th>
                      <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Avg Value
                      </th>
                      <th className="px-6 py-3 bg-gray-50 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                        Avg Frequency
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    <tr>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        High Value
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">45</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">$5,245.32</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">12.3</td>
                    </tr>
                    <tr>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        Regular
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">85</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">$2,856.45</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">7.8</td>
                    </tr>
                    <tr>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        Occasional
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">120</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">$1,234.56</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">4.2</td>
                    </tr>
                    <tr>
                      <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                        New/Low Value
                      </td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">50</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">$456.78</td>
                      <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">1.5</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

export default App;