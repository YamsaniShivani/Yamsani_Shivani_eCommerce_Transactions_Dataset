import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import davies_bouldin_score, silhouette_score
from sklearn.metrics.pairwise import cosine_similarity
import json
from datetime import datetime

# Load and prepare data
def load_data():
    # Create DataFrames from the provided data
    transactions_data = '''TransactionID,CustomerID,ProductID,TransactionDate,Quantity,TotalValue,Price
    [Your transaction data here]'''  # Add the full transaction data
    
    products_data = '''ProductID,ProductName,Category,Price
    [Your product data here]'''  # Add the full product data
    
    customers_data = '''CustomerID,CustomerName,Region,SignupDate
    [Your customer data here]'''  # Add the full customer data
    
    transactions_df = pd.read_csv(pd.StringIO(transactions_data))
    products_df = pd.read_csv(pd.StringIO(products_data))
    customers_df = pd.read_csv(pd.StringIO(customers_data))
    
    # Convert dates to datetime
    transactions_df['TransactionDate'] = pd.to_datetime(transactions_df['TransactionDate'])
    customers_df['SignupDate'] = pd.to_datetime(customers_df['SignupDate'])
    
    return transactions_df, products_df, customers_df

def perform_eda(transactions_df, products_df, customers_df):
    # Merge datasets
    merged_df = transactions_df.merge(customers_df, on='CustomerID')
    merged_df = merged_df.merge(products_df, on='ProductID')
    
    # Calculate key metrics
    total_revenue = merged_df['TotalValue'].sum()
    avg_order_value = merged_df.groupby('TransactionID')['TotalValue'].mean()
    
    # Category analysis
    category_metrics = merged_df.groupby('Category').agg({
        'TotalValue': ['sum', 'count'],
        'Quantity': 'sum'
    }).round(2)
    
    # Regional analysis
    regional_metrics = merged_df.groupby('Region').agg({
        'TotalValue': ['sum', 'mean'],
        'CustomerID': 'nunique'
    }).round(2)
    
    # Time series analysis
    daily_revenue = merged_df.groupby('TransactionDate')['TotalValue'].sum().reset_index()
    daily_revenue['MovingAverage'] = daily_revenue['TotalValue'].rolling(window=7).mean()
    
    insights = {
        'total_revenue': float(total_revenue),
        'avg_order_value': float(avg_order_value.mean()),
        'category_metrics': {
            'revenue': category_metrics['TotalValue']['sum'].to_dict(),
            'orders': category_metrics['TotalValue']['count'].to_dict(),
            'quantity': category_metrics['Quantity']['sum'].to_dict()
        },
        'regional_metrics': {
            'revenue': regional_metrics['TotalValue']['sum'].to_dict(),
            'avg_order_value': regional_metrics['TotalValue']['mean'].to_dict(),
            'customers': regional_metrics['CustomerID']['nunique'].to_dict()
        },
        'time_series': {
            'dates': daily_revenue['TransactionDate'].dt.strftime('%Y-%m-%d').tolist(),
            'revenue': daily_revenue['TotalValue'].tolist(),
            'moving_avg': daily_revenue['MovingAverage'].tolist()
        }
    }
    
    with open('src/data/insights.json', 'w') as f:
        json.dump(insights, f)

def build_lookalike_model(transactions_df, products_df, customers_df):
    # Create customer features
    customer_features = transactions_df.groupby('CustomerID').agg({
        'TotalValue': ['sum', 'mean', 'count'],
        'Quantity': ['sum', 'mean'],
    }).round(2)
    
    # Add customer profile features
    customer_profile = pd.get_dummies(customers_df[['CustomerID', 'Region']], columns=['Region'])
    customer_features = customer_features.merge(customer_profile, on='CustomerID')
    
    # Normalize features
    feature_cols = customer_features.columns.difference(['CustomerID'])
    scaler = StandardScaler()
    features_normalized = scaler.fit_transform(customer_features[feature_cols])
    
    # Calculate similarity matrix
    similarity_matrix = cosine_similarity(features_normalized)
    
    # Get top 3 similar customers for first 20 customers
    lookalikes = {}
    for i in range(20):
        customer_id = customer_features.iloc[i]['CustomerID']
        similarities = similarity_matrix[i]
        top_indices = np.argsort(similarities)[-4:-1][::-1]  # Exclude self
        
        lookalikes[customer_id] = [
            {
                'customer_id': customer_features.iloc[idx]['CustomerID'],
                'score': float(similarities[idx])
            }
            for idx in top_indices
        ]
    
    with open('src/data/lookalikes.json', 'w') as f:
        json.dump(lookalikes, f)

def perform_clustering(transactions_df, products_df, customers_df):
    # Prepare features for clustering
    customer_features = transactions_df.groupby('CustomerID').agg({
        'TotalValue': ['sum', 'mean', 'count'],
        'Quantity': ['sum', 'mean'],
    }).round(2)
    
    # Add customer profile features
    customer_profile = pd.get_dummies(customers_df[['CustomerID', 'Region']], columns=['Region'])
    customer_features = customer_features.merge(customer_profile, on='CustomerID')
    
    # Normalize features
    feature_cols = customer_features.columns.difference(['CustomerID'])
    scaler = StandardScaler()
    features_normalized = scaler.fit_transform(customer_features[feature_cols])
    
    # Find optimal number of clusters
    db_scores = []
    silhouette_scores = []
    for k in range(2, 11):
        kmeans = KMeans(n_clusters=k, random_state=42)
        clusters = kmeans.fit_predict(features_normalized)
        db_score = davies_bouldin_score(features_normalized, clusters)
        silhouette_avg = silhouette_score(features_normalized, clusters)
        
        db_scores.append({'k': k, 'db_score': float(db_score)})
        silhouette_scores.append({'k': k, 'silhouette_score': float(silhouette_avg)})
    
    # Get best k based on Davies-Bouldin score
    best_k = min(db_scores, key=lambda x: x['db_score'])['k']
    
    # Final clustering
    kmeans = KMeans(n_clusters=best_k, random_state=42)
    clusters = kmeans.fit_predict(features_normalized)
    
    # Calculate cluster metrics
    customer_features['Cluster'] = clusters
    cluster_metrics = []
    for i in range(best_k):
        cluster_data = customer_features[customer_features['Cluster'] == i]
        metrics = {
            'cluster_id': i,
            'size': len(cluster_data),
            'avg_value': float(cluster_data['TotalValue']['sum'].mean()),
            'avg_frequency': float(cluster_data['TotalValue']['count'].mean())
        }
        cluster_metrics.append(metrics)
    
    clustering_results = {
        'db_scores': db_scores,
        'silhouette_scores': silhouette_scores,
        'best_k': best_k,
        'cluster_assignments': [int(c) for c in clusters],
        'customer_ids': customer_features.index.tolist(),
        'cluster_metrics': cluster_metrics
    }
    
    with open('src/data/clustering.json', 'w') as f:
        json.dump(clustering_results, f)

if __name__ == '__main__':
    transactions_df, products_df, customers_df = load_data()
    
    perform_eda(transactions_df, products_df, customers_df)
    build_lookalike_model(transactions_df, products_df, customers_df)
    perform_clustering(transactions_df, products_df, customers_df)